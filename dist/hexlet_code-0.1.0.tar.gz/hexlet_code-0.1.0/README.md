### Hexlet tests and linter status:
[![Actions Status](https://github.com/Yagamama/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Yagamama/python-project-50/actions)

<a href="https://codeclimate.com/github/Yagamama/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/6b3700ce925a1aa71f34/maintainability" /></a>

https://asciinema.org/a/FVVPkiqrDPxgQEFizHi15ILqI
