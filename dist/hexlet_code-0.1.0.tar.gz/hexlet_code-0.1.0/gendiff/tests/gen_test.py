import pytest


pytest_plugins = [
    "fixtures.big_strings.py"
]