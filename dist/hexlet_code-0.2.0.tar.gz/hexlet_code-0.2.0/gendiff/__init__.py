from .modules.gendiffer import generate_diff

__all__ = (
    'generate_diff',
)
