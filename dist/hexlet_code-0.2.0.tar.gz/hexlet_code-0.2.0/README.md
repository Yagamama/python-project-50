### Hexlet tests and linter status:
[![Actions Status](https://github.com/Yagamama/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Yagamama/python-project-50/actions)

<a href="https://codeclimate.com/github/Yagamama/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/6b3700ce925a1aa71f34/maintainability" /></a>

<a href="https://codeclimate.com/github/Yagamama/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/b0d1a8541e86b4fab3fa/test_coverage" /></a>

https://asciinema.org/a/FVVPkiqrDPxgQEFizHi15ILqI
