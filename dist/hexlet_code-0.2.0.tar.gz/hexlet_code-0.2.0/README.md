### Hexlet tests and linter status:
[![Actions Status](https://github.com/Yagamama/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Yagamama/python-project-50/actions)

<a href="https://codeclimate.com/github/Yagamama/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/6b3700ce925a1aa71f34/maintainability" /></a>

<a href="https://codeclimate.com/github/Yagamama/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/b0d1a8541e86b4fab3fa/test_coverage" /></a>

https://asciinema.org/a/FVVPkiqrDPxgQEFizHi15ILqI

https://asciinema.org/a/ZoL1JQ1Doser6NKQ6ti2z9Dlm step 5

https://asciinema.org/a/QmDjDQd4CBQwMEYVFOu2LBhDy step 6

https://asciinema.org/a/nz3QftF2OB7A8bejX3DIeHJKp step 7

https://asciinema.org/a/T3w5EaHg20I6FpxBzgrkP0Lvh step 8