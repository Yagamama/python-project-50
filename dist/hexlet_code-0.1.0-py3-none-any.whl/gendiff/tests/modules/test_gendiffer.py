import pytest
from gendiff import generate_diff
from pathlib import Path
import sys
sys.path.append('../../fixtures')
path = Path(__file__).absolute().parent.parent.joinpath('fixtures')
from fixtures.big_strings import files1_and_1, files1_and_2


# @pytest.fixture
# def big_string():
#     return '''{
#   - follow: false
#     host: hexlet.io
#   - proxy: 123.234.53.22
#   - timeout: 50
#   + timeout: 20
#   + verbose: true
# }'''


def test_generate_diff():
    p = Path(__file__)
    cur_dir = p.absolute().parent.parent.parent
    file1 = cur_dir.joinpath('jsons/file1.json')
    file2 = cur_dir.joinpath('jsons/file2.json')
    assert generate_diff(file1, file2) == files1_and_2
    assert generate_diff(file1, file1) == files1_and_1
